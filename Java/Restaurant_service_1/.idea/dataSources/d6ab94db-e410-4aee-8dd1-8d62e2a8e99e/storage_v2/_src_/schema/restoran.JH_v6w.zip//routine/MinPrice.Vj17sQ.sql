create
    definer = root@localhost procedure MinPrice()
BEGIN
select deliverycompanies.DeliveryCompanyId from deliverycompanies where PricePercent = (select min(PricePercent) from deliverycompanies);
END;


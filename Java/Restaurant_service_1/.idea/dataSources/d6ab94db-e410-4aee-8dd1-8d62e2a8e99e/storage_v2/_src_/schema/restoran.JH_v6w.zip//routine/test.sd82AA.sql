create
    definer = root@localhost procedure test()
BEGIN
select d.DishID, d.Title, d.Price from dishes d where d.price > 50;
END;

